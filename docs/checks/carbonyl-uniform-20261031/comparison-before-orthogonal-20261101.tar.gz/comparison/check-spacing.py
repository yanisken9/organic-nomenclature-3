"""Check the approved spacing revision against the saved vertical preview."""
from pathlib import Path
import runpy,tarfile,math,json,hashlib
HERE=Path(__file__).resolve().parent
h=runpy.run_path(str(HERE/'prepare.py'));parse=h['parse']
baseline=json.loads((HERE/'spacing-baseline.json').read_text())
archive=HERE.parents[3]/baseline['snapshot']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==baseline['snapshotSHA256']
geometry=json.loads((HERE/'geometry.json').read_text());rows=[]
with tarfile.open(archive,'r:gz')as saved:
    for index,item in enumerate(geometry['molecules']):
        key=item['key'];old=saved.extractfile('comparison/'+key+'-proposed.mol').read().decode()
        new=(HERE/(key+'-proposed.mol')).read_text()
        ol,oa,ob=parse(old);nl,na,nb=parse(new)
        assert len(oa)==len(na)and ob==nb
        assert ol[:4]==nl[:4]and ol[4+len(oa):]==nl[4+len(na):]
        assert all(x[20:]==y[20:]for x,y in zip(ol[4:4+len(oa)],nl[4:4+len(na)]))
        near=[[]for _ in oa]
        for a,b,o in ob:near[a].append(b);near[b].append(a)
        allowed=set();stems={frozenset(i-1 for i in edge['atoms']):edge['proposed']for edge in item['stems']}
        if index==4:assert new==old
        else:
            target=.588 if index<4 else .3713
            assert set(stems.values())=={target}
            for edge in item['stems']:
                parent,child=[i-1 for i in edge['atoms']];seen={parent};pending=[child]
                while pending:
                    i=pending.pop()
                    if i in seen:continue
                    seen.add(i);allowed.add(i);pending.extend(near[i])
        if index==3:
            allowed.update([10,11])
            assert na[11][:2]==(round(na[3][0]-.3094,4),na[3][1])
            assert na[10][:2]==(na[2][0],round(na[2][1]+.3094,4))
            assert na[6][0]==na[4][0]and na[6][1]<na[4][1]
            assert na[12][:2]==(round(na[4][0]-.3094,4),na[4][1])
        if index==1:
            assert na[25][:2]==(round(na[7][0]-.3094,4),na[7][1])
            for terminal,side in [(8,1),(9,-1)]:
                dx,dy=na[terminal][0]-na[7][0],na[terminal][1]-na[7][1]
                assert dx*side>0 and dy>0 and abs(math.degrees(math.atan2(dy,abs(dx)))-60)<.01
                hs=[i for i in near[terminal]if na[i][2]=='H']
                tx=na[7][0]+side*.6188/2;ty=na[7][1]+.6188*math.sqrt(3)/2
                for atom,(dx,dy)in zip(hs,[(side*.3094,0),(side*.3094/2,.3094*math.sqrt(3)/2),
                                          (side*.3094/2,-.3094*math.sqrt(3)/2)]):
                    # MOL rounds final coordinates once, not the parent first.
                    assert na[atom][:2]==(round(tx+dx,4),round(ty+dy,4))
        changed={i for i in range(len(oa))if oa[i][:2]!=na[i][:2]};assert changed<=allowed
        for a,b,o in ob:
            expected=stems.get(frozenset((a,b)),math.dist(oa[a][:2],oa[b][:2]))
            assert abs(math.dist(na[a][:2],na[b][:2])-expected)<.00006,(key,a+1,b+1)
        bonded={frozenset((a,b))for a,b,o in ob}
        minimum=min(math.dist(na[a][:2],na[b][:2])for a in range(len(na))for b in range(a)if frozenset((a,b))not in bonded)
        assert minimum>.1547
        for c,atom in enumerate(na):
            for a,b,o in ob:
                if c in [a,b]:continue
                ax,ay=na[a][:2];bx,by=na[b][:2];cx,cy=atom[:2]
                dx,dy=bx-ax,by-ay;t=((cx-ax)*dx+(cy-ay)*dy)/(dx*dx+dy*dy)
                assert not(0<t<1 and math.hypot(cx-ax-t*dx,cy-ay-t*dy)<1e-7),(key,c+1,a+1,b+1)
        def cross(i,j,k):
            x,y=na[i][:2];u,v=na[j][:2];q,r=na[k][:2]
            return(u-x)*(r-y)-(v-y)*(q-x)
        for bi,(a,b,o)in enumerate(ob):
            for c,d,p in ob[:bi]:
                if len({a,b,c,d})<4:continue
                assert not(cross(a,b,c)*cross(a,b,d)<-1e-12 and cross(c,d,a)*cross(c,d,b)<-1e-12)
                if abs(cross(a,b,c))<1e-9 and abs(cross(a,b,d))<1e-9:
                    axis=0 if abs(na[a][0]-na[b][0])>abs(na[a][1]-na[b][1])else 1
                    lo=max(min(na[a][axis],na[b][axis]),min(na[c][axis],na[d][axis]))
                    hi=min(max(na[a][axis],na[b][axis]),max(na[c][axis],na[d][axis]))
                    assert hi-lo<1e-7
        assert (HERE/(key+'-before.mol')).read_bytes()==saved.extractfile('comparison/'+key+'-before.mol').read()
        rows.append({'key':key,'orangeLengths':list(stems.values()),'changedAtomIDs':sorted(i+1 for i in changed),
                     'minimumNonbondedDistance':minimum,'unchangedGraphIDsNonXY':True,
                     'unaffectedCoordinatesPreserved':True,'clearGeometry':True})
out={'passed':True,'date':'2026-11-01','previewOnly':True,'molecules':rows,
     'fifthUnchanged':True,'MOLRoundingLengthTolerance':.00006}
(HERE/'spacing-geometry-check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'passed':True,'molecules':len(rows),'fifthUnchanged':True}))
