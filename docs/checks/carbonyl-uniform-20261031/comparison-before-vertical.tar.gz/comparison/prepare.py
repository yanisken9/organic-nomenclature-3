"""Generate six approved preview candidates; never writes application sources."""
from pathlib import Path
import gzip,json,math,runpy
ROOT=Path(__file__).resolve().parents[4];HERE=Path(__file__).resolve().parent
helpers=runpy.run_path(str(ROOT/'docs/checks/enyne-uniform-20261031/transform.py'))
parse=helpers['parse'];literal=helpers['literal']
KEYS=['ethyl_2_methyl_3_pentanal','ethyl_4_isopropyl_3_methyl_2_hexanal',
      'ethyl_4_penten_4_yn_2_al','isopropyl_2_buten_2_dial',
      'trimethyl_3_4_4_pentanone_2','diethyl_4_5_dimethyl_2_6_heptanone_3']
def proposal(mol,key):
    lines,atoms,bonds=parse(mol);near=[[]for _ in atoms];heavy=[i for i,a in enumerate(atoms)if a[2]!='H']
    assert len(bonds)==len(atoms)-1
    for a,b,o in bonds:near[a].append((b,o));near[b].append((a,o))
    root=heavy[0];xy={root:(atoms[root][0]*.6188/1.17,atoms[root][1]*.6188/1.17)};pending=[root];stems=[]
    def add(a,b,length):
        dx,dy=atoms[b][0]-atoms[a][0],atoms[b][1]-atoms[a][1];r=math.hypot(dx,dy);assert r>0
        xy[b]=(xy[a][0]+dx/r*length,xy[a][1]+dy/r*length)
    while pending:
        a=pending.pop()
        for b,o in near[a]:
            if atoms[b][2]=='H'or b in xy:continue
            old_length=math.dist(atoms[a][:2],atoms[b][:2]);units=old_length/1.17;target=.6188
            if key==KEYS[4]:
                if set([a+1,b+1])=={4,8}:target=.98
            elif key==KEYS[5]:
                if units>1.5:target=.6188*(units+1)/2
            elif units>1.5:target=.98
            if target!=.6188:stems.append({'atoms':[a+1,b+1],'original':old_length,'proposed':round(target,4)})
            add(a,b,target);pending.append(b)
    assert all(i in xy for i in heavy)
    for i,a in enumerate(atoms):
        if a[2]=='H':assert len(near[i])==1;add(near[i][0][0],i,.3094)
    assert len(xy)==len(atoms)
    points={i:tuple(round(v,4)for v in p)for i,p in xy.items()};assert len(set(points.values()))==len(atoms)
    for i in range(len(atoms)):
        x,y=points[i];lines[4+i]='%10.4f%10.4f'%(x or 0.,y or 0.)+lines[4+i][20:]
    return ''.join(lines),stems
if __name__=='__main__':
    data=(ROOT/'js/jsme-nick-nomeclature-moc2-data_52.js').read_text();rows=[];originals={}
    for key in KEYS:
        mol=literal(data,key)[1];new,stems=proposal(mol,key)
        (HERE/(key+'-before.mol')).write_text(mol);(HERE/(key+'-proposed.mol')).write_text(new)
        originals[key]=mol;rows.append({'key':key,'stems':stems})
    (HERE/'originals.json.gz').write_bytes(gzip.compress(json.dumps(originals).encode(),mtime=0))
    code=(ROOT/'js/mulermoc-nom-molview-52.js').read_text();start=code.index('function fPrepareFixedCCAlkanePrototype()');end=code.index('function fGetUniform2DLibraryFrame()',start)
    original=code[start:end].strip();assert original.count('const etherScale = [')==1
    preview=original.replace('const etherScale = [','const etherScale = ['+','.join(json.dumps(k)for k in KEYS)+',',1)
    (HERE/'original-calibration.js').write_text(original+'\n');(HERE/'preview-calibration.js').write_text(preview+'\n')
    (HERE/'geometry.json').write_text(json.dumps({'previewOnly':True,'normalHeavy':.6188,'CH':.3094,'molecules':rows},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'previewMolecules':len(rows),'mainSourcesWritten':False}))
